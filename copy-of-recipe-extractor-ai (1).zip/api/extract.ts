// This is a Vercel Serverless Function, which will be detected automatically.
// It acts as a secure proxy to the Google Gemini API.

import { GoogleGenAI, Type } from "@google/genai";
import type { GeminiRecipe } from '../types';

// The VercelRequest and VercelResponse types are available globally in Vercel's environment.
// We can define a simplified version for local development and type safety if needed.
interface VercelRequest {
  body: {
    url: string;
  };
}

interface VercelResponse {
  status: (code: number) => {
    json: (data: any) => void;
  };
}

const recipeSchema = {
    type: Type.OBJECT,
    properties: {
      title: { 
        type: Type.STRING, 
        description: "The full, user-friendly title of the recipe." 
      },
      ingredients: {
        type: Type.ARRAY,
        description: "A complete list of all ingredients, including quantities, units, and any preparation notes (e.g., 'chopped', 'softened').",
        items: { type: Type.STRING }
      },
      instructions: {
        type: Type.ARRAY,
        description: "A list of step-by-step cooking instructions. Each step should be a separate item in the array.",
        items: { type: Type.STRING }
      }
    },
    required: ["title", "ingredients", "instructions"]
};

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(500).json({ error: 'API key is not configured on the server.' });
  }

  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'URL is required.' });
  }

  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const systemInstruction = "You are an expert recipe parsing agent. Your primary function is to extract recipe data from webpages. You must analyze the content and return a JSON object containing the recipe's title, a list of ingredients, and a list of cooking instructions. Adhere strictly to the provided JSON schema. Do not include any explanatory text or markdown formatting outside of the JSON object itself.";
    const userPrompt = `Please extract the recipe from the following URL: ${url}`;

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userPrompt,
        config: {
            systemInstruction: systemInstruction,
            responseMimeType: "application/json",
            responseSchema: recipeSchema,
        },
    });

    let jsonText = response.text.trim();
    if (jsonText.startsWith('```json')) {
        jsonText = jsonText.substring(7, jsonText.length - 3).trim();
    }
    
    const parsedData = JSON.parse(jsonText) as GeminiRecipe;
    
    return res.status(200).json(parsedData);

  } catch (error) {
    console.error('Error calling Gemini API:', error);
    return res.status(500).json({ error: 'Failed to extract recipe data.' });
  }
}
