
import React, { useState, useCallback } from 'react';
import type { Recipe } from '../types';
import { CheckIcon, ClipboardIcon, SaveIcon, LinkIcon, LeafIcon } from './icons';

interface RecipeCardProps {
  recipe: Recipe;
  onSave: (recipe: Recipe) => void;
  isSaved: boolean;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe, onSave, isSaved }) => {
  const [copied, setCopied] = useState(false);

  const formatRecipeForCopy = useCallback(() => {
    let text = `${recipe.title}\n\n`;
    text += "--- INGREDIENTS ---\n";
    text += recipe.ingredients.join('\n');
    text += "\n\n--- INSTRUCTIONS ---\n";
    text += recipe.instructions.map((inst, i) => `${i + 1}. ${inst}`).join('\n');
    text += `\n\nSource: ${recipe.url}`;
    return text;
  }, [recipe]);

  const handleCopy = useCallback(() => {
    navigator.clipboard.writeText(formatRecipeForCopy()).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    });
  }, [formatRecipeForCopy]);
  
  const handleSave = useCallback(() => {
      onSave(recipe);
  }, [onSave, recipe]);

  return (
    <div className="bg-white rounded-2xl shadow-xl animate-fade-in transition-all duration-500 overflow-hidden border border-gray-200/50">
      <div className="p-6 sm:p-8 bg-gradient-to-br from-white to-gray-50 border-b border-gray-200/80">
        <h2 className="text-3xl lg:text-4xl font-bold text-brand-dark font-serif">{recipe.title}</h2>
        <a href={recipe.url} target="_blank" rel="noopener noreferrer" className="text-sm text-brand-primary hover:text-red-500 transition-colors duration-200 mt-2 inline-flex items-center space-x-1.5 group">
            <LinkIcon className="h-4 w-4" />
            <span className="group-hover:underline">View Original Recipe</span>
        </a>
      </div>
      
      <div className="p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:space-x-4 space-y-3 sm:space-y-0 mb-8">
            <button
                onClick={handleCopy}
                className="w-full sm:w-auto flex-1 inline-flex items-center justify-center px-4 py-3 border-2 border-blue-300/80 text-sm font-semibold rounded-lg text-blue-800 bg-blue-100/70 hover:bg-blue-200/70 hover:border-blue-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-all duration-200"
            >
                {copied ? <CheckIcon className="h-5 w-5 mr-2 text-blue-900" /> : <ClipboardIcon className="h-5 w-5 mr-2" />}
                {copied ? 'Copied to Clipboard!' : 'Copy Recipe'}
            </button>
            <button
                onClick={handleSave}
                disabled={isSaved}
                className="w-full sm:w-auto flex-1 inline-flex items-center justify-center px-4 py-3 border-2 border-transparent text-sm font-semibold rounded-lg text-white bg-brand-accent hover:bg-emerald-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-accent transition-all duration-200 disabled:bg-gray-400 disabled:text-gray-100 disabled:cursor-not-allowed disabled:hover:bg-gray-400"
            >
                <SaveIcon className="h-5 w-5 mr-2" />
                {isSaved ? 'Saved to Collection' : 'Save Recipe'}
            </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-4">
            <h3 className="text-2xl font-semibold text-brand-dark font-serif border-b-2 border-blue-400 pb-2 mb-4">Ingredients</h3>
            <div className="bg-emerald-50/50 p-4 rounded-lg">
                <ul className="space-y-3 text-brand-text">
                  {recipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-start">
                      <LeafIcon className="flex-shrink-0 text-emerald-600 mr-2.5 mt-1 h-4 w-4" />
                      <span>{ingredient}</span>
                    </li>
                  ))}
                </ul>
            </div>
          </div>
          <div className="lg:col-span-8">
            <h3 className="text-2xl font-semibold text-brand-dark font-serif border-b-2 border-blue-400 pb-2 mb-4">Instructions</h3>
            <ol className="space-y-5 text-brand-text">
              {recipe.instructions.map((instruction, index) => (
                <li key={index} className="flex items-start leading-relaxed">
                  <span className="flex-shrink-0 bg-gradient-to-br from-brand-primary to-red-500 text-white font-bold rounded-full h-7 w-7 text-base flex items-center justify-center mr-4 mt-px shadow">{index + 1}</span>
                  <span>{instruction}</span>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};