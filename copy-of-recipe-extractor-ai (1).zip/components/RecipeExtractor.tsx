
import React, { useState, useCallback, useEffect } from 'react';
import { extractRecipeFromUrl } from '../services/geminiService';
import type { Recipe } from '../types';
import { RecipeCard } from './RecipeCard';
import { LoadingSpinner } from './LoadingSpinner';
import { SearchIcon, SparklesIcon } from './icons';

interface RecipeExtractorProps {
  onSave: (recipe: Recipe) => void;
  initialRecipe: Recipe | null;
  isRecipeSaved: (url: string) => boolean;
}

export const RecipeExtractor: React.FC<RecipeExtractorProps> = ({ onSave, initialRecipe, isRecipeSaved }) => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [extractedRecipe, setExtractedRecipe] = useState<Recipe | null>(null);

  useEffect(() => {
    if (initialRecipe) {
        setExtractedRecipe(initialRecipe);
        setUrl(initialRecipe.url);
        setError(null);
    }
  }, [initialRecipe]);

  const handleExtract = useCallback(async () => {
    if (!url.trim()) {
      setError('Please enter a valid URL.');
      return;
    }
    
    try {
        new URL(url);
    } catch (_) {
        setError('The entered text is not a valid URL. Please include http:// or https://');
        return;
    }

    setIsLoading(true);
    setError(null);
    setExtractedRecipe(null);

    try {
      const recipeData = await extractRecipeFromUrl(url);
      setExtractedRecipe({ ...recipeData, url });
    } catch (err) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An unexpected error occurred.');
      }
    } finally {
      setIsLoading(false);
    }
  }, [url]);

  return (
    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-xl space-y-6 border border-gray-200/50">
      <div>
        <label htmlFor="url-input" className="block text-xl font-medium text-brand-dark mb-3 font-serif">
          Enter Recipe URL
        </label>
        <div className="flex space-x-3">
          <input
            id="url-input"
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleExtract()}
            placeholder="https://www.yourfavoriterecipe.com/..."
            className="flex-grow block w-full px-4 py-3 bg-gray-50 text-brand-dark border border-gray-300 rounded-lg shadow-sm placeholder:text-gray-400 focus:outline-none focus:ring-2 focus:ring-brand-primary focus:border-brand-primary transition duration-150 ease-in-out text-base"
            disabled={isLoading}
          />
          <button
            onClick={handleExtract}
            disabled={isLoading}
            className="flex items-center justify-center px-6 py-3 bg-brand-primary text-white font-semibold rounded-lg shadow-md hover:bg-red-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-all duration-200 ease-in-out disabled:bg-gray-400 disabled:cursor-not-allowed transform hover:scale-105"
          >
            {isLoading ? <LoadingSpinner /> : <SearchIcon className="h-6 w-6" />}
            <span className="ml-2 hidden sm:inline text-base">Extract</span>
          </button>
        </div>
      </div>
      
      <div className="mt-6">
        {isLoading && (
          <div className="text-center py-10">
            <LoadingSpinner size="lg" color="text-brand-primary" />
            <p className="mt-4 text-lg text-gray-700 font-serif">Extracting deliciousness...</p>
            <p className="text-gray-500">This may take a moment.</p>
          </div>
        )}
        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-800 p-4 rounded-md shadow" role="alert">
            <p className="font-bold">Extraction Failed</p>
            <p>{error}</p>
          </div>
        )}
        {!isLoading && !error && !extractedRecipe && (
            <div className="text-center py-12 px-6 bg-amber-50/50 border-2 border-dashed border-amber-300 rounded-xl">
                <SparklesIcon className="h-12 w-12 text-amber-500 mx-auto" />
                <h3 className="mt-4 text-xl font-semibold text-amber-900 font-serif">Let's Get Cooking!</h3>
                <p className="mt-2 text-amber-800 max-w-md mx-auto">Paste a recipe link above, and we'll use AI to magically organize it for you.</p>
            </div>
        )}
        {extractedRecipe && (
          <RecipeCard 
            recipe={extractedRecipe} 
            onSave={onSave}
            isSaved={isRecipeSaved(extractedRecipe.url)}
           />
        )}
      </div>
    </div>
  );
};
