
import React from 'react';
import type { Recipe } from '../types';
import { TrashIcon, BookOpenIcon, SaveIcon } from './icons';

interface SavedRecipesListProps {
  recipes: Recipe[];
  onSelect: (recipe: Recipe) => void;
  onDelete: (url: string) => void;
}

export const SavedRecipesList: React.FC<SavedRecipesListProps> = ({ recipes, onSelect, onDelete }) => {
  return (
    <div className="bg-white/80 backdrop-blur-sm p-6 rounded-2xl shadow-xl border border-gray-200/50">
      <div className="flex items-center mb-5 border-b-2 border-blue-400 pb-3">
        <SaveIcon className="h-7 w-7 text-brand-accent mr-3" />
        <h3 className="text-2xl font-bold text-brand-dark font-serif">My Collection</h3>
        <span className="ml-auto bg-brand-accent text-white text-sm font-bold rounded-full px-3 py-1">{recipes.length}</span>
      </div>
      {recipes.length === 0 ? (
        <div className="text-center py-8 px-4 bg-gray-50/80 rounded-lg">
          <p className="font-semibold text-gray-600">Your collection is empty.</p>
          <p className="text-sm text-gray-500 mt-1">Click "Save Recipe" on a recipe to add it here!</p>
        </div>
      ) : (
        <ul className="space-y-2 max-h-[60vh] overflow-y-auto pr-2">
          {recipes.map((recipe) => (
            <li key={recipe.url} className="group flex items-center justify-between rounded-lg hover:bg-blue-100 transition-all duration-200 ease-in-out">
              <button
                onClick={() => onSelect(recipe)}
                className="flex items-center space-x-3 text-left w-full p-3"
              >
                <BookOpenIcon className="h-5 w-5 text-brand-primary flex-shrink-0" />
                <span className="font-medium text-brand-text group-hover:text-brand-dark transition-colors truncate">{recipe.title}</span>
              </button>
              <button
                onClick={(e) => {
                    e.stopPropagation(); // prevent selection when deleting
                    onDelete(recipe.url);
                }}
                className="mr-2 p-2 rounded-full text-gray-400 hover:bg-red-100 hover:text-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 transition-colors duration-150 flex-shrink-0"
                aria-label={`Delete ${recipe.title}`}
              >
                <TrashIcon className="h-5 w-5" />
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};