import type { GeminiRecipe } from '../types';

export const extractRecipeFromUrl = async (url: string): Promise<GeminiRecipe> => {
    try {
        const response = await fetch('/api/extract', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ url }),
        });

        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.error || `Server responded with status: ${response.status}`);
        }

        const parsedData = await response.json() as GeminiRecipe;

        // Validate that the essential fields are present.
        if (!parsedData.title || !Array.isArray(parsedData.ingredients) || !Array.isArray(parsedData.instructions)) {
            console.error("Incomplete data received from server:", parsedData);
            throw new Error("The AI could not recognize a valid recipe structure on the page.");
        }

        return parsedData;

    } catch (error) {
        console.error("Error during recipe extraction process:", error);
        if (error instanceof Error) {
             throw error; // Re-throw the error
        }
        throw new Error(`Failed to extract recipe. Please check the URL and your connection.`);
    }
};
